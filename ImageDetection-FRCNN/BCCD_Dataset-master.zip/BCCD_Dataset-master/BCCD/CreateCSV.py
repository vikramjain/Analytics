#Python code to illustrate parsing of XML files 
# importing the required modules to CSV format
import csv 
import requests 
import xml.etree.ElementTree as ET 
import pandas as pd
import os

CSV_FILENAME = 'train.csv'

def getXMLFileName(i): 
	fileName = "./Annotations/BloodImage_"
	if i < 10:
		fileName = fileName + str("0000") + str(i) + str(".xml")
	elif i < 100:
		fileName = fileName + str("000") + str(i) + str(".xml")
	else:
		fileName = fileName + str("00") + str(i) + str(".xml")
	return fileName
		

def parseXML(xmlfile): 
	# create element tree object 
	tree = ET.parse(xmlfile) 
	# get root element 
	root = tree.getroot() 
	# create empty list for object items 
	objectitems = [] 
	# iterate object items 
	for item in root.findall('object'): 
		# empty object dictionary 
		object = {} 
		# iterate child elements of item 
		for child in item:
			name = ''
			xmin = 0
			ymin = 0
			xmax = 0
			ymax = 0
			if(child.tag == "name"):
				name =  child.text
				object['cell_type'] = name
			elif(child.tag == 'bndbox'):
				for subchild in child:
					if(subchild.tag == "xmin"):
						xmin =  subchild.text
						object['xmin'] = xmin
					elif(subchild.tag == "ymin"):
						ymin =  subchild.text
						object['ymin'] = ymin
					elif(subchild.tag == "xmax"):
						xmax =  subchild.text
						object['xmax'] = xmax
					elif(subchild.tag == "ymax"):
						ymax =  subchild.text
						object['ymax'] = ymax
		# append news dictionary to news items list 
		object['image_names'] = xmlfile.replace('./Annotations/','').replace('.xml','.jpg')
		objectitems.append(object) 	
	return objectitems 

def savetoCSV(objectitems, filename, i): 
	# specifying the fields for csv file 
	fields = ['image_names', 'xmin', 'ymin', 'xmax', 'ymax', 'cell_type'] 
	# writing to csv file 
	with open(filename, 'a') as csvfile: 
		# creating a csv dict writer object 
		writer = csv.DictWriter(csvfile, fieldnames = fields) 
		# writing headers (field names)
		if(i==0):
			writer.writeheader() 
		# writing data rows 
		writer.writerows(objectitems) 
	#removing empty lines
	df = pd.read_csv(filename)
	df.to_csv(filename, index=False)

def main(): 
	if os.path.exists(CSV_FILENAME):
		os.remove(CSV_FILENAME)
	# load rss from web to update existing xml file
	for i in range(400):
		try:
			items = parseXML(getXMLFileName(i)) 
			# store news items in a csv file 
			savetoCSV(items, CSV_FILENAME, i) 
		except IOError:
			print('An error occured trying to read the file.')
	
if __name__ == "__main__": 
	# calling main function 
	main() 
